const options = ["Rock", "Paper", "Scissors"];

function getComputerChoice() {
    return options[Math.floor(Math.random() * 3)];
}

function determineWinner(player, computer) {
    if (player === computer) {
        return "Draw";
    }

    if (
        (player === "Rock" && computer === "Scissors") ||
        (player === "Paper" && computer === "Rock") ||
        (player === "Scissors" && computer === "Paper")
    ) {
        return "Player";
    }

    return "Computer";
}

function playRound(player, computer) {
    console.log("Your choice:", player);
    console.log("Computer choice:", computer);

    let result = determineWinner(player, computer);

    console.log("Round result:", result);

    return result;
}

function playMatch() {
    let playerPoints = 0;
    let computerPoints = 0;

    while (playerPoints < 2 && computerPoints < 2) {
        let player = options[Math.floor(Math.random() * 3)];
        let computer = getComputerChoice();

        let result = playRound(player, computer);

        if (result === "Player") {
            playerPoints++;
        }
        else if (result === "Computer") {
            computerPoints++;
        }

        console.log("Player:", playerPoints);
        console.log("Computer:", computerPoints);
        console.log("------------------");
    }

    console.log(playerPoints === 2 ? "You won!" : "Computer won!");
}

playMatch();