let marks = [78, 45, 92, 61, 38, 84, 73, 56, 49, 95];

console.log("Marks:", marks);

let total = 0;

for (let i = 0; i < marks.length; i++) {
    total += marks[i];
}

console.log("Total Marks:", total);

let average = total / marks.length;
console.log("Average Marks:", average);

let highest = Math.max(...marks);
let lowest = Math.min(...marks);

console.log("Highest Marks:", highest);
console.log("Lowest Marks:", lowest);

let passed = 0;
let failed = 0;

for (let i = 0; i < marks.length; i++) {
    if (marks[i] >= 50) {
        passed++;
    }
    else {
        failed++;
    }
}

console.log("Passed Students:", passed);
console.log("Failed Students:", failed);

let grades = marks.map(function(mark) {
    if (mark >= 80) {
        return "A";
    }
    else if (mark >= 70) {
        return "B";
    }
    else if (mark >= 50) {
        return "C";
    }
    else {
        return "Fail";
    }
});

console.log("Grades:", grades);

let passedMarks = marks.filter(function(mark) {
    return mark >= 50;
});

console.log("Passed Marks:", passedMarks);

let ascending = [...marks].sort((a, b) => a - b);
console.log("Ascending:", ascending);

let descending = [...marks].sort((a, b) => b - a);
console.log("Descending:", descending);

let uniqueMarks = [...new Set(marks)];
console.log("Unique Marks:", uniqueMarks);

let searchMark = 84;

console.log(
    marks.includes(searchMark)
        ? "Mark found"
        : "Mark not found"
);