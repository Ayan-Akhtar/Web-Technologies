let profile = {
    productName: "Wireless Bluetooth Earbuds",
    brand: "Audionic",
    price: 1850,
    color: "White",
    rating: 4.2,
    reviews: 156,
    deliveryCharges: 120,
    warranty: "6 Months"
};

console.log(profile);

console.log("Product Name:", profile.productName);
console.log("Price:", profile.price);
console.log("Color:", profile.color);