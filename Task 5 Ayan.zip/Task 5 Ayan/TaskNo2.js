let density = "Medium";
let emergency = false;

if (emergency === true) {
    console.log("Green light for 90 seconds");
}
else if (density === "High") {
    console.log("Green light for 60 seconds");
}
else if (density === "Medium") {
    console.log("Green light for 40 seconds");
}
else if (density === "Low") {
    console.log("Green light for 20 seconds");
}
else {
    console.log("Invalid traffic density");
}